import DataFrame from "./src/DataFrame.js";

// Extra helper functions
export function readCSV(csvString) {
  return DataFrame.fromCSV(csvString);
}

export function toCSV(df) {
  return df.toCSV();
}

export function head(df, n = 5) {
  return df.head(n);
}

export function describe(df) {
  return df.describe();
}

// Default export
export default DataFrame;
